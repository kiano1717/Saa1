import 'package:equatable/equatable.dart';

part 'users.dart';
part 'products.dart';