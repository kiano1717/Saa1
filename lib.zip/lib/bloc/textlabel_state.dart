part of 'textlabel_bloc.dart';

@immutable
class TextlabelState {
  final String value;

  TextlabelState(this.value);
}

