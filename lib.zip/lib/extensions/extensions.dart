import 'package:firebase_auth/firebase_auth.dart';
import 'package:bloc_practice/models/models.dart';

part 'firebase_user_extension.dart';
